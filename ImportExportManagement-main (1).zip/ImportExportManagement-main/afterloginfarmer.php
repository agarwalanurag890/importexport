<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>farmer after login</title>
</head>
<body>
        <div class="container">
            <table>
                <tr>
                  <th>Farmer id</th>
                  <th>Product name</th>
                  <th>Price per unit</th>
                </tr>
                <tr>
                  <td>1</td>
                  <td>mango</td>
                  <td>1500</td>
                </tr>
                <tr>
                  <td>2</td>
                  <td>banana</td>
                  <td>30</td>
                </tr>
              </table>
        </div>
</body>
</html>